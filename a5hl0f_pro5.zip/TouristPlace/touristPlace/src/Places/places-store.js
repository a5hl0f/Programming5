import { writable } from 'svelte/store';

const places = writable([
  {
    id: 'm1',
    title: 'Taj Mahal',
    subtitle: 'love',
    description:
      'An immense mausoleum of white marble',
    imageUrl:
      'https://media.istockphoto.com/photos/taj-mahal-agra-india-monument-of-love-in-blue-sky-picture-id519330110?k=20&m=519330110&s=612x612&w=0&h=c6aWpRD_0BrCvL6D_UTS23jtYqXgcqkJ1mCzHa7lpCM=',
    address: 'India Agara',
    contactEmail: 'india@test.com',
    isFavorite: false
  },
  {
    id: 'm2',
    title: 'Maldievs Resort',
    subtitle: "Let's go for some swimming",
    description: 'We will simply swim some rounds!',
    imageUrl:
      'https://images.news18.com/ibnlive/uploads/2021/09/1600x1600px_b.jpg',
    address: 'Maldives',
    contactEmail: 'swim@test.com',
    isFavorite: false
  }
]);

const customPlaceStore = {
  subscribe: places.subscribe,
  addplace: placesData => {
    const newPlaces = {
      ...placesData,
      id: Math.random().toString(),
      isFavorite: false
    };
    places.update(items => {
      return [newPlaces, ...items];
    });
  },
    updatePlace: (id, placesData) => {
        places.update(items => {
            const placeIndex = items.findIndex(i => i.id === id);
            const updatedPlace = { ...items[placeIndex], ...placesData };
      const updatedplaces = [...items];
      updatedplaces[meetupIndex] = updatedPlace;
      return updatedplaces;
    });
  },
  removeplace: (id) => {
      places.update(items => {
        return items.filter(i => i.id !== id);
      });
  },
    toggleFavorite: id => {
        places.update(items => {
      const updatedplace = { ...items.find(m => m.id === id) };
      updatedplace.isFavorite = !updatedplace.isFavorite;
      const placeIndex = items.findIndex(m => m.id === id);
      const updatedplaces = [...items];
      updatedplaces[placeIndex] = updatedplace;
      return updatedplaces;
    });
  }
};

export default customPlaceStore;
