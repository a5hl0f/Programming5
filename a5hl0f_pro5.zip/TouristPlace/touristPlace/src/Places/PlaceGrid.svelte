<script>
  import { createEventDispatcher } from "svelte";
  import PlaceItem from "./PlaceItem.svelte";
  import PlaceFilter from "./PlacesFilter.svelte";
  import Button from "../UI/Button.svelte";

  export let places;

  const dispatch = createEventDispatcher();

  let favsOnly = false;

  $: filteredplaces = favsOnly ? places.filter(m => m.isFavorite) : places;

  function setFilter(event) {
    favsOnly = event.detail === 1;
  }
</script>

<style>
  #places {
    width: 100%;
    display: grid;
    grid-template-columns: 1fr;
    grid-gap: 1rem;
  }

  #places-controls {
    margin: 1rem;
    display: flex;
    justify-content: space-between;
  }

  @media (min-width: 768px) {
    #places {
      grid-template-columns: repeat(2, 1fr);
    }
  }
</style>

<section id="places-controls">
  <PlaceFilter on:select={setFilter} />
  <Button on:click={() => dispatch('add')}>New Place</Button>
</section>
<section id="places">
  {#each filteredplaces as place}
    <PlaceItem
      id={place.id}
      title={place.title}
      subtitle={place.subtitle}
      description={place.description}
      imageUrl={place.imageUrl}
      email={place.contactEmail}
      address={place.address}
      isFav={place.isFavorite}
      on:showdetails
      on:edit />
  {/each}
</section>
