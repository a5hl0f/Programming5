<script>
  import places from "./Places/places-store.js";
  import Header from "./UI/Header.svelte";
  import PlaceGrid from "./Places/PlaceGrid.svelte";
  import TextInput from "./UI/TextInput.svelte";
  import Button from "./UI/Button.svelte";
  import EditPlace from "./Places/Editplaces.svelte";
  import PlaceDetail from "./Places/PlacesDetail.svelte";

  

  let editMode;
  let editedId;
  let page = "overview";
  let pageData = {};

  function savedPlace(event) {
    editMode = null;
    editedId = null;
  }

  function cancelEdit() {
    editMode = null;
    editedId = null;
  }

  function showDetails(event) {
    page = "details";
    pageData.id = event.detail;
  }

  function closeDetails() {
    page = "overview";
    pageData = {};
  }

  function startEdit(event) {
    editMode = "edit";
    editedId = event.detail;
  }
</script>

<style>
  main {
    margin-top: 5rem;
  }
</style>

<Header />

<main>
  {#if page === 'overview'}
    {#if editMode === 'edit'}
      <EditPlace id={editedId} on:save={savedPlace} on:cancel={cancelEdit} />
    {/if}
    <PlaceGrid
      places={$places}
      on:showdetails={showDetails}
      on:edit={startEdit}
      on:add={() => {editMode = 'edit'}} />
  {:else}
    <PlaceDetail id={pageData.id} on:close={closeDetails} />
  {/if}
</main>
 